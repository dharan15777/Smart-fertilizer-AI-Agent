import pandas as pd

# Load soil data
data = pd.read_csv("soil_data.csv")

def fertilizer_agent(nitrogen, phosphorus, potassium):
    fertilizer = 0
    explanation = []

    if nitrogen < 30:
        fertilizer += 60
        explanation.append("Low Nitrogen: +60 kg/ha")
    elif nitrogen < 50:
        fertilizer += 40
        explanation.append("Medium Nitrogen: +40 kg/ha")
    else:
        fertilizer += 20
        explanation.append("High Nitrogen: +20 kg/ha")

    if phosphorus < 20:
        fertilizer += 40
        explanation.append("Low Phosphorus: +40 kg/ha")
    elif phosphorus < 40:
        fertilizer += 25
        explanation.append("Medium Phosphorus: +25 kg/ha")
    else:
        fertilizer += 10
        explanation.append("High Phosphorus: +10 kg/ha")

    if potassium < 25:
        fertilizer += 30
        explanation.append("Low Potassium: +30 kg/ha")
    elif potassium < 45:
        fertilizer += 20
        explanation.append("Medium Potassium: +20 kg/ha")
    else:
        fertilizer += 10
        explanation.append("High Potassium: +10 kg/ha")

    return fertilizer, explanation

print("AI Fertilizer Recommendations:\n")

for index, row in data.iterrows():
    fert, reason = fertilizer_agent(
        row["nitrogen"],
        row["phosphorus"],
        row["potassium"]
    )

    print(f"Zone {row['zone']}: {fert} kg/ha")
    for r in reason:
        print(" -", r)
    print()
