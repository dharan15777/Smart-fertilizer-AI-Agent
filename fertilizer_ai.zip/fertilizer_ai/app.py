from flask import Flask, render_template, request

app = Flask(__name__)

def fertilizer_agent(n, p, k):
    fertilizer = 0
    reasons = []

    if n < 30:
        fertilizer += 60
        reasons.append("Low Nitrogen")
    elif n < 50:
        fertilizer += 40
        reasons.append("Medium Nitrogen")
    else:
        fertilizer += 20
        reasons.append("High Nitrogen")

    if p < 20:
        fertilizer += 40
        reasons.append("Low Phosphorus")
    elif p < 40:
        fertilizer += 25
        reasons.append("Medium Phosphorus")
    else:
        fertilizer += 10
        reasons.append("High Phosphorus")

    if k < 25:
        fertilizer += 30
        reasons.append("Low Potassium")
    elif k < 45:
        fertilizer += 20
        reasons.append("Medium Potassium")
    else:
        fertilizer += 10
        reasons.append("High Potassium")

    return fertilizer, reasons

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    reasons = []

    if request.method == "POST":
        n = int(request.form["nitrogen"])
        p = int(request.form["phosphorus"])
        k = int(request.form["potassium"])

        result, reasons = fertilizer_agent(n, p, k)

    return render_template("index.html", result=result, reasons=reasons)

if __name__ == "__main__":
    app.run(debug=True)
